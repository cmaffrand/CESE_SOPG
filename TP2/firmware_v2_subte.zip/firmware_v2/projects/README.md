In this folder you can add your personal projects. They will be ignored by this repository.
